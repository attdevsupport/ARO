Excerpt included from documentation from the AT&T Developer Portal: http://developer.att.com/application-resource-optimizer/docs

This package includes the ARO Open Collector distributed under the Apache 2.0 license for your convienience.

------------------------------------

Testing Android Devices

Prerequisites
To collect an application trace for your Android device, you'll need the following:
	-The latest version of the Android SDK and Android Platform installed on your local computer
	-Android version 2.4x or above installed on your test device
	-A USB driver installed on your test device
	-The AT&T ARO Data Collector APK

------------------------------------

Installing the AT&T ARO Data Collector APK

-Connect your Android device to the computer using a USB cable.
-Verify the connection between the device and the computer by issuing the following command:
-Open your terminal or command window and navigate to the platform-tools directory in your Android SDK.

	>>> adb devices
      
-If the connection is successful, you should see your device listed in the command output.

-Once the device connection is verified, install the Data Collector APK by typing:
	
	>>> adb install filename.apk

------------------------------------
       
Collecting the Trace

Once you have successfully installed the AT&T ARO Data Collector on your test device, you can collect a trace by either operating the Data Collector directly on your device or from your computer. 

Note: Operating the Data Collector from your computer allows you to capture a video of the trace via USB for Android devices that do not support the AT&T ARO Data Collector capturing trace video directly.

Operating AT&T ARO Data Collector from your computer via USB cable:
	-Connect your test device to your local computer via USB.
	-To ensure the Data Collector is working properly on your device, start the AT&T ARO Data Collector on your test device, then stop it.
	-Open AT&T ARO (a.k.a 'AROAnalyzer') from your computer.
	-Click 'Data Collector' in the main menu of AT&T ARO, and click 'Start Collector'.
	-Enter a name for the trace folder (or accept the default name), using alphanumeric letters only. 
	-Click 'OK'.
	-Click 'Hide Collector', open your application, and begin testing.
	-When you have finished testing, go back to AT&T ARO and click 'Stop Collector'. 
	-Click 'OK' to complete collecting the trace.

The trace data, including video, will be automatically transferred to your computer via USB. Once the trace folder is saved to your computer, you are ready to perform analysis on the trace using the AT&T ARO Data Analyzer.

Operating AT&T ARO Data Collector on your test device:
	-Launch AT&T ARO in your test device and accept the Terms and Conditions.
	-Open the Task Killer to stop any applications and tasks that you do not want to test.
	-Make sure the 'Record Video' box is checked if you would like to trace capture video.
	-Click 'Start Collector'.
	-Enter a name for the trace folder (or accept the default name), using alphanumeric letters only. Click 'OK'.
	-Click 'Hide Collector', open your application, and begin testing.
	-When you have finished testing, go back to AT&T ARO and click 'Stop Collector'. Click 'OK' to complete collecting the trace.
	-To pull the trace to your computer, mount the device SD card as Mass Storage. This will bring up a new drive on your computer.
	-On your device, select the file to copy to your computer from the On-Going notification on the Android slider age bar.

Once the trace folder is saved to your computer, you are ready to perform analysis on the trace using the AT&T ARO Data Analyzer.

